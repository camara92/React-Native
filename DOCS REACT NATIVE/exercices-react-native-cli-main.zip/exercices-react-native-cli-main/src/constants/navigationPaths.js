export default {
    HOME: 'Home',
    PROFILE: 'Profile',
    TABNAV: 'TabNav'
}