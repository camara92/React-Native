export default {
    iconHome: require('../assets/images/outline_home_black_24pt_1x.png'),
    iconProfile: require('../assets/images/outline_face_black_24pt_1x.png'),
}