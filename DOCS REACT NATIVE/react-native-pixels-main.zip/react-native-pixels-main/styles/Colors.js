export default {
    white: '#ffffff',
    clicked: 'palevioletred',
    lightBrown: 'salmon',
    darkGrey: "#333",
    ghost: 'ghostwhite',
    lightGrey: '#767577'
}