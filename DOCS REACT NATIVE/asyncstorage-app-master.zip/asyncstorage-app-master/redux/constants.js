export const AUTH_USER = 'AUTH_USER';
export const INFO_USER = 'INFO_USER';
export const LOGOUT_USER = 'LOGOUT_USER';
