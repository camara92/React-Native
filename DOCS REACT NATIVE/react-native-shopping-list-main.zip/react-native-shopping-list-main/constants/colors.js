export default {
    white: "#fff",
    danger: "darkred",
    info: "lightseagreen",
    success: "seagreen",
    warning: "tomato",
    secondary: "lightgrey",
    dark: "black",
    grey: "#333"
}