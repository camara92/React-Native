export default {
    green: "#3FA477",
    white: "#fff",
    dimGray: "dimgray",
    darkGrey: '#333',
    lightGrey: '#ccc',
    lightOrange: "moccasin",
    orange: 'orange'
}