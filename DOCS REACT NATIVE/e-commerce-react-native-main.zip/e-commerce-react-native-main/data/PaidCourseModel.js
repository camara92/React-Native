class PaidCourse {
    constructor(id, price, title) {
        this.id = id;
        this.price = price;
        this.title = title;
    }
}

export default PaidCourse