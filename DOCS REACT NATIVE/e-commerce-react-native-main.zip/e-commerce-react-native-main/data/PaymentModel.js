// {id, courses, total, date}
class PaymentModel {
    constructor(id, courses, total, date) {
        this.id = id;
        this.courses = courses;
        this.total = total;
        this.date = date;
    }
}

export default PaymentModel;